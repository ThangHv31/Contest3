package hdt.triangle;

public class Triangle {
    private Point a;
    private Point b;
    private Point c;
    public Triangle(Point a, Point b, Point c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    static double khoangCach(Point A, Point B) {
        return Math.sqrt((A.getX()- B.getX()) * (A.getX() - B.getX()) + (A.getY() - B.getY()) * (A.getY() - B.getY()));
    }

    double getPerimeter() {
        double chuVi = khoangCach(this.a, this.b) + khoangCach(this.a, this.c) + khoangCach(this.b, this.c);
        return Math.round(chuVi * 1000) / 1000;
    }

    boolean valid() {
        if (khoangCach(this.a, this.b) + khoangCach(this.a, this.c) > khoangCach(this.b, this.c)
                && khoangCach(this.a, this.b) + khoangCach(this.b, this.c) > khoangCach(this.a, this.c)
                && khoangCach(this.c, this.b) + khoangCach(this.a, this.c) > khoangCach(this.a, this.b)) {
            return true;
        }
        return false;
    }
}
