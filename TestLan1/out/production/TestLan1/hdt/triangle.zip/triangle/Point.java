package hdt.triangle;

import java.util.Scanner;

public class Point {
    private Float x;
    private Float y;

    public Float getX() {
        return x;
    }

    public void setX(Float x) {
        this.x = x;
    }

    public Float getY() {
        return y;
    }

    public void setY(Float y) {
        this.y = y;
    }

    public Point(Float x, Float y) {
        this.x = x;
        this.y = y;
    }

    static Point nextPoint(Scanner scanner) {
        return new Point(scanner.nextFloat(), scanner.nextFloat());
    }
}
